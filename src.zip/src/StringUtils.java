public class StringUtils {
    final static String MENU_FOR_5_ELEMENTS = "1-scissors\n2-paper\n3-rock\n4-lizard\n5-spock\n0-exit";
    final static String MENU_FOR_3_ELEMENTS = "1-paper\n2-rock\n3-scissors\n0-exit";
}
